import torch
import numpy as np
import random
import math

from PPO_model import PolicyNetwork, CriticNetwork

gamma = 0.8             # discount factor
lamda= 0.9              # parameter for the Generalized Advantage Estimation
LR = 1e-3
BUFFER_SIZE = 2048
BATCH_SIZE = 512
NUM_EPOCHS = 3

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def get_TD_residuals(REWARDS, VALUES, DONES, gamma=gamma):
    num_agents = REWARDS[0].size()[0]
    action_size = REWARDS[0].size()[1]
    TD_residuals = []
    GAMMA = torch.full((num_agents,action_size), gamma, dtype=torch.float, device=device)
    for state in range(len(REWARDS)-1):
           TD_residuals.append(REWARDS[state] + GAMMA * VALUES[state+1].detach() * (1-DONES[state]) - VALUES[state].detach())
    TD_residuals.append(torch.zeros(num_agents, action_size))
    return TD_residuals

def get_adv_and_returns(REWARDS, VALUES, DONES, gamma=gamma, lamda=lamda):
    num_agents = REWARDS[0].size()[0]
    action_size = REWARDS[0].size()[1]
    R = get_TD_residuals(REWARDS, VALUES, DONES)
    GAMMA = torch.full((num_agents,action_size), gamma, dtype=torch.float, device=device)
    LAMDA = torch.full((num_agents,action_size), lamda, dtype=torch.float, device=device)
    advantages = []
    returns = []
    advantages.append(R[-1])
    returns.append(REWARDS[-1])
    for state in range(len(REWARDS)-1,-1,-1):
            advantages.append(R[state].to(device) + GAMMA * LAMDA * advantages[-1].to(device) * (1-DONES[state]))
            returns.append(REWARDS[state] + GAMMA * returns[-1].to(device) * (1-DONES[state]))
    adv_tensor = torch.zeros(len(REWARDS),num_agents, action_size, dtype=torch.float, device=device)
    ret_tensor = torch.zeros_like(adv_tensor)
    for k in range(len(REWARDS)):
        adv_tensor[k][:][:] = advantages[k][:][:]
        ret_tensor[k][:][:] = returns[k][:][:]
    mean = torch.mean(adv_tensor, 0)
    std = torch.std(adv_tensor, 0)
    for k in range(len(REWARDS)):
            adv_tensor[k] = (adv_tensor[k] - mean) / (std + 1.0e-10) 
    return adv_tensor.to(device), ret_tensor.to(device)
            

def eval_log_densities(actions, means, log_stds):
    stds = torch.exp(log_stds)
    var = torch.pow(stds,2)
    log_densities = -(actions - means)**2 / (2 * var) - 0.5 * (math.log(2 * math.pi) + log_stds)
    return log_densities

def get_best_actions(policy_network, states):
    policy_network.eval()
    with torch.no_grad():
        params = policy_network.forward(states)
        means, logstds = params[0].cpu().data.numpy(), params[1]
    policy_network.train()
    stds = torch.exp(logstds).cpu().data.numpy()
    gauss_distr = torch.distributions.Normal(0,1)
    gauss_var = gauss_distr.sample().cpu().data.numpy()
    best_actions = means + stds * gauss_var

    return np.clip(best_actions,-1,1)
    

def collect_trajectories(env, brain_name, num_agents, state_size, action_size, policy_network, buffer_size=BUFFER_SIZE):                  
    
    STATES = torch.empty(buffer_size, num_agents, state_size).to(device, torch.float)
    ACTIONS = []
    REWARDS = []
    DONES = []
    rewards = torch.zeros(num_agents, action_size)
    dones = torch.zeros(num_agents, action_size)
    env_info = env.reset(train_mode=True)[brain_name]
    
    for t in range(buffer_size):
        STATES[t] = torch.from_numpy(env_info.vector_observations).to(device, torch.float)
        actions = get_best_actions(policy_network, STATES[t])
        env_info = env.step(actions)[brain_name]
        ACTIONS.append(torch.from_numpy(actions).to(torch.float))
        for k in range(num_agents):
            rewards[k][:] = env_info.rewards[k]                           
        REWARDS.append(rewards)
        D = np.where(np.asarray(env_info.local_done)==False, 0, 1)
        D = torch.from_numpy(D).to(torch.float) 
        for k in range(num_agents):
            dones[k][:] = D[k]
        DONES.append(dones) 
        if np.any(env_info.local_done):
            if (t < buffer_size-1):
                for k in range(buffer_size-t-1):
                    ACTIONS.append(torch.zeros(num_agents, action_size))
                    REWARDS.append(torch.zeros(num_agents, action_size))
                    DONES.append(torch.ones(num_agents, action_size))
            break                                                  
        
    return STATES, ACTIONS, REWARDS, DONES

class Agent():
    def __init__(self, num_agents, state_size, action_size, buffer_size=BUFFER_SIZE, batch_size=BATCH_SIZE, random_seed=0):
        self.seed = random.seed(random_seed)
        self.policy_network = PolicyNetwork(num_agents, state_size, action_size, random_seed).to(device) 
        self.critic_network = CriticNetwork(num_agents, state_size, action_size, random_seed).to(device)
        self.policy_optim = torch.optim.Adam(self.policy_network.parameters(), lr=LR)
        self.critic_optim = torch.optim.Adam(self.critic_network.parameters(), lr=LR)
        self.batch_new_policies = torch.zeros(batch_size, num_agents, action_size, dtype=torch.float)
        self.batch_new_values = torch.zeros(batch_size, num_agents, action_size, dtype=torch.float)


    def perform_learning_with(self, STATES, ACTIONS, REWARDS, DONES, epsilon, num_epochs=NUM_EPOCHS, batch_size=BATCH_SIZE):
        for k in range(len(ACTIONS)):
            STATES[k] = STATES[k].to(device)
            ACTIONS[k] = ACTIONS[k].to(device)
            REWARDS[k] = REWARDS[k].to(device)
            DONES[k] = DONES[k].to(device)
        for k in range(batch_size):
            self.batch_new_values[k] = self.batch_new_values[k].to(device)
        T = np.arange(len(ACTIONS))
        for epoch in range(num_epochs):
            np.random.shuffle(T)
            for i in range(len(ACTIONS)//batch_size):
                batch_index = T[batch_size*i : batch_size*(i+1)]
                batch_rewards = REWARDS[batch_index]
                batch_dones = DONES[batch_index]
                batch_index = torch.LongTensor(batch_index).to(device)
                batch_states = STATES[batch_index]
                batch_old_values = self.batch_new_values
                batch_old_policies = self.batch_new_policies.detach()
                self.batch_new_values = self.critic_network.forward(batch_states.squeeze(1)) 
        
                batch_advant, batch_returns = get_adv_and_returns(batch_rewards, self.batch_new_values, batch_dones)
        
                params = self.policy_network.forward(batch_states.squeeze(1))
        
                self.batch_new_policies = eval_log_densities(ACTIONS[batch_index], params[0].to(device), params[1].to(device))            
                  
                self.updating_step(batch_advant, batch_old_policies, batch_returns, batch_old_values, epsilon)
                
    
    def updating_step(self, batch_advant, batch_old_policies, batch_returns, batch_old_values, epsilon):
        ratios = torch.exp(self.batch_new_policies-batch_old_policies).to(device)
        clipped_ratios = torch.clamp(ratios, 1.0 - epsilon, 1.0 + epsilon).to(device)
      
        actor_losses = ratios * batch_advant
        clipped_actor_losses = clipped_ratios * batch_advant
        selected_actor_losses = -torch.min(actor_losses, clipped_actor_losses)
        mean_actor_losses = torch.mean(selected_actor_losses,1).to(device) # mean over agents
        surrogate_losses = torch.mean(mean_actor_losses,0).to(device) # mean over batch
    
        clipped_values = batch_old_values + torch.clamp(self.batch_new_values - batch_old_values, -epsilon, epsilon)
        mse = torch.nn.MSELoss()
        MSE_losses = torch.zeros_like(batch_advant).to(device)
        clipped_MSE_losses = torch.zeros_like(batch_advant).to(device)
        for k in range(batch_returns.size()[0]):
            for i in range(batch_returns.size()[1]):
                for j in range(batch_returns.size()[2]):
                    MSE_losses[k][i][j] = mse(self.batch_new_values[k][i][j], batch_returns[k][i][j])
                    clipped_MSE_losses[k][i][j] = mse(clipped_values[k][i][j], batch_returns[k][i][j])
        selected_critic_losses = torch.max(MSE_losses,clipped_MSE_losses).to(device)
        mean_critic_losses = torch.mean(selected_critic_losses,1).to(device) # mean over all the agents 
        critic_losses = torch.mean(mean_critic_losses,0).to(device) # mean over time_step 
     
        total_losses = surrogate_losses + 0.5 * critic_losses 
        self.critic_optim.zero_grad()
        total_losses.backward(torch.ones(batch_returns.size()[2]).to(device), retain_graph=True)
        self.critic_optim.step()

        self.policy_optim.zero_grad()
        total_losses.backward(torch.ones(batch_returns.size()[2]).to(device), retain_graph=True)
        self.policy_optim.step() 